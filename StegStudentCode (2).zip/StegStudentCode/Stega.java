
/**
 * Write a description of class code here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.Color;
public class Stega
{
        public static void clearLow( Pixel p)
        {p.setRed((p.getRed()/4)*4);
         p.setGreen((p.getGreen()/4)*4);
         p.setBlue((p.getBlue()/4)*4);
        }
    
        public static Picture testClearlow( Picture p)
        {Pixel[][] pixels = p.getPixels2D();
            for(int row = 0; row < pixels.length; row++)
            {
                for(int col = 0; col < pixels[row].length; col++)
                {
                    clearLow(pixels[row][col]);
                }
            }
            return p;
        }
    
    public static Picture testSetlow( Picture p, Color c)
        {Pixel[][] pixels = p.getPixels2D();
            for(int row = 0; row < pixels.length; row++)
            {
                for(int col = 0; col < pixels[row].length; col++)
                {
                    setLow(pixels[row][col],c);
                }
            }
            return p;
    }
    
    public static void setLow (Pixel p, Color c){
        clearLow(p);
        p.setRed(p.getRed() + c.getRed()/64);
        p.setGreen(p.getGreen() + c.getGreen()/64);
        p.setBlue(p.getBlue() + c.getBlue()/64);
    }
    public static void main(String[] args){
            Picture motorcycle = new Picture ("blueMotorcycle.jpg");
            Picture mark = new Picture ("blue-mark.jpg");
            motorcycle.explore();
            if(canHide(motorcycle, mark)){
                Picture copy = hidePicture(motorcycle,mark);
                copy.explore();
                Picture copy2 = revealPicture(motorcycle);
                copy2.explore();
            }
    }

    public static Picture revealPicture(Picture hidden) 
    { 
        Picture copy = new Picture(hidden); 
        Pixel[][] pixels = copy.getPixels2D(); 
        Pixel[][] source = hidden.getPixels2D(); 
        for (int r = 0; r < pixels.length; r++)
        { 
          for (int c = 0; c < pixels[0].length; c++) 
          { 
              Color col = source[r][c].getColor(); 
              pixels[r][c].setRed((col.getRed() - ((col.getRed()/4)*4))*64);
              pixels[r][c].setGreen((col.getGreen() - ((col.getGreen()/4)*4))*64);
              pixels[r][c].setBlue((col.getBlue() - ((col.getBlue()/4)*4))*64);
            } 
        } 
        return copy; 
    }
    
    public static boolean canHide(Picture source, Picture secret){
        Pixel[][] pixelsSource = source.getPixels2D(); 
        Pixel[][] pixelsSecret = secret.getPixels2D();
        if(pixelsSource.length == pixelsSecret.length && pixelsSource[0].length == pixelsSecret[0].length){
            return true;
        }
        else{
            return false;
        }
    
    }
    public static Picture hidePicture(Picture source, Picture secret){
        Pixel[][] pixelsSource = source.getPixels2D(); 
        Pixel[][] pixelsSecret = secret.getPixels2D();
        
        for(int row = 0;row < pixelsSource.length;row++){
            for(int col = 0; col<pixelsSource[row].length;col++){
                setLow(pixelsSource[row][col],pixelsSecret[row][col].getColor());
            }
        }
        
        return source;
    }
    
}

