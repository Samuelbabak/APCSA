
/**
 * Write a description of class mainGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.io.IOException;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUIS implements ActionListener
{   
    private static JButton createAccount;
    public static JPanel mainMenuGUI() {
        JPanel main = new JPanel();
        main.setLayout(null);
        
        JLabel BankName= new JLabel("Samuel's Bank");
        BankName.setFont(new Font("Serif", Font.BOLD, 35));
        BankName.setBounds(100, 15, 1000, 30);
        main.add(BankName);
        
        createAccount = new JButton("Create Account");
        createAccount.setBounds(15, 150, 180, 25);
        createAccount.addActionListener(new GUIS());
        main.add(createAccount);
 
        JLabel newUser = new JLabel("Username");
        newUser.setBounds(10, 90, 80, 25);
        main.add(newUser);
        
        JTextField userText = new JTextField(20);
        userText.setBounds(100, 90, 165, 25);
        main.add(userText);
        
        JLabel passwordLabel = new JLabel("password");
        passwordLabel.setBounds(10, 120, 80, 25);
        main.add(passwordLabel);
        
        JPasswordField passwordText = new JPasswordField();
        passwordText.setBounds(100, 120, 165, 25);
        main.add(passwordText);
        
        return main;
    }
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(createAccount)){
            System.out.println("test");
            }
    }
      public static void main(String[] args)throws IOException{
        for(BankAccount account : GUI2.accountCheck()){
            System.out.println(account.toString()+ "\n");
        }
    }
    public JButton getCreate(){
        return createAccount;
    }
}
