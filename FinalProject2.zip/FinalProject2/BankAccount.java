
/**
 * This is the code nessary to make the BankAccounts and store all of their values in a single object.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.PrintWriter;
import java.io.File;
import java.io.IOException;


public class BankAccount
{
    private double balance;
    private String username;
    private String password;
    private double savings;
    public BankAccount(String username, String password, double balance,double savings){
        this.username = username;
        this.password = password;
        this.balance = balance;
        this.savings=savings;
        }
    
        //getters and setters to access information of different accounts
    public String getUsername(){
        return this.username;
    }
    public String getPassword(){
        return this.password;
    }
    public double getBalance(){
        return this.balance;
    }
    public double getSavings(){
        return this.savings;
    }
    public void setBalance(double amount){
        this.balance=amount;
    }
    public void setSavings(double amount){
        this.savings=amount;
    }
    public String formatAccount(){
        return this.username+";"+this.password+";"+this.balance+";"+this.savings;
    }
    public String toString(){
        return "User: " + this.username + "\nPassword: " + this.password + "\nAccount Balance: " + this.balance;
    }
    public void loginAttempt(){
      
    }
    public void createAccount(){
      System.out.println("Please");
    }
}

