
/**
 * Write a description of class Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.IOException;
public class Tester
{
    public static void main(String[] args) throws IOException{
     
     GUI2 sam = new GUI2();
     sam.GUI2();
     GUI2.accountCheck();
    }
}
