
/**
 * Write a description of class Functions here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Functions
{   
    private static String[] check ={"h","j","k"};
    public static void sleep(int x){
        
        
         System.out.println(asList(check).indexOf("h"));
        
    }
}
