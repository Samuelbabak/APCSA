/**
 * Class to show how to define a very simple class.
 * 
 * Copyright Georgia Institute of Technology 2004
 * @author Barb Ericson ericson@cc.gatech.edu
 */
public class Greeter 
{
  public static void main(String[] argv) 
  { 
    // show the string "Hello World" on the console 
    System.out.println("Hello World");
  }
}