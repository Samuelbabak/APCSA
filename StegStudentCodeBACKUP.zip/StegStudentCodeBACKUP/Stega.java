
/**
 * Write a description of class code here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.Color;
import java.util.ArrayList;
import java.awt.Point;
public class Stega
{
    public static void clearLow( Pixel p){
        p.setRed((p.getRed()/4)*4);
        p.setGreen((p.getGreen()/4)*4);
        p.setBlue((p.getBlue()/4)*4);
    }
    
    public static Picture testClearlow( Picture p){
         Pixel[][] pixels = p.getPixels2D();
         for(int row = 0; row < pixels.length; row++)
         {
            for(int col = 0; col < pixels[row].length; col++){
               clearLow(pixels[row][col]);
                }
            }
         return p;
        }
    
    public static Picture testSetlow( Picture p, Color c){
          Pixel[][] pixels = p.getPixels2D();
          for(int row = 0; row < pixels.length; row++){
              for(int col = 0; col < pixels[row].length; col++){
                    setLow(pixels[row][col],c);
              }
          }
          return p;
    }
    
    public static void setLow (Pixel p, Color c){
        clearLow(p);
        p.setRed(p.getRed() + c.getRed()/64);
        p.setGreen(p.getGreen() + c.getGreen()/64);
        p.setBlue(p.getBlue() + c.getBlue()/64);
    }
    public static void main(String[] args){
            // Picture motorcycle = new Picture ("blueMotorcycle.jpg");
            // Picture mark = new Picture ("barbaraS.jpg");
            // motorcycle.explore();
            // Picture copy = hidePicture(motorcycle,mark,20,20);
            // copy.explore();
            // Picture copy2 = revealPicture(motorcycle);
            // copy2.explore();
            //---------------------------
            // Picture swan = new Picture("swan.jpg");
            // Picture swan2 = new Picture("swan.jpg");
            // System.out.println("Swan and swan2 are the same: " +
            // isSame(swan, swan2));
            // swan = testClearlow(swan);
            // System.out.println("Swan and swan2 are the same (after clearLow run on swan): "+ isSame(swan, swan2));
            //----------------------------------
            Picture arch = new Picture("arch.jpg");
            Picture arch2 = new Picture("arch.jpg");
            Picture koala = new Picture("koala.jpg") ;
            Picture robot1 = new Picture("robot.jpg");
            ArrayList<Point> pointList = findDifferences(arch, arch2);
            System.out.println("PointList after comparing two identical s pictures " +
            "has a size of " + pointList.size());
            pointList = findDifferences(arch, koala);
            System.out.println("PointList after comparing two different sized pictures " +
            "has a size of " + pointList.size());
            arch2 = hidePicture(arch2, robot1, 65, 102);
            pointList = findDifferences(arch, arch2);
            System.out.println("Pointlist after hiding a picture has a size of"
            + pointList.size());
            arch2 = showDifferentArea(arch, pointList);
            arch.show();
            arch2.show(); 
    }

    public static Picture revealPicture(Picture hidden) 
    { 
        Picture copy = new Picture(hidden); 
        Pixel[][] pixels = copy.getPixels2D(); 
        Pixel[][] source = hidden.getPixels2D(); 
        for (int r = 0; r < pixels.length; r++)
        { 
          for (int c = 0; c < pixels[0].length; c++) 
          { 
              Color col = source[r][c].getColor(); 
              pixels[r][c].setRed((col.getRed() - ((col.getRed()/4)*4))*64);
              pixels[r][c].setGreen((col.getGreen() - ((col.getGreen()/4)*4))*64);
              pixels[r][c].setBlue((col.getBlue() - ((col.getBlue()/4)*4))*64);
            } 
        } 
        return copy; 
    }
    
    public static boolean canHide(Picture source, Picture secret){
        Pixel[][] pixelsSource = source.getPixels2D(); 
        Pixel[][] pixelsSecret = secret.getPixels2D();
        if(pixelsSource.length == pixelsSecret.length && pixelsSource[0].length == pixelsSecret[0].length){
            return true;
        }
        else{
            return false;
        }
    
    }
    public static Picture hidePicture(Picture source, Picture secret, int startRow, int startCol){
        Pixel[][] pixelsSource = source.getPixels2D(); 
        Pixel[][] pixelsSecret = secret.getPixels2D();
        
        for(int row = 0;row < pixelsSecret.length;row++){
            for(int col = 0; col<pixelsSecret[row].length;col++){
                setLow(pixelsSource[row + startRow][col + startCol],pixelsSecret[row][col].getColor());
            }
        }
        
        return source;
    }
    public static Picture hidePicture(Picture source, Picture secret){
        Pixel[][] pixelsSource = source.getPixels2D(); 
        Pixel[][] pixelsSecret = secret.getPixels2D();
        
        for(int row = 0;row < pixelsSource.length;row++){
            for(int col = 0; col<pixelsSource[row].length;col++){
                setLow(pixelsSource[row][col],pixelsSecret[row][col].getColor());
            }
        }
        
        return source;
    }
    
    public static boolean isSame(Picture pic1, Picture pic2){
        Pixel[][] pixels1 = pic1.getPixels2D(); 
        Pixel[][] pixels2 = pic2.getPixels2D();
        if(canHide(pic1,pic2)){
        for(int r=0; r<pixels1.length;r++){
             for(int c=0; c<pixels1[r].length;c++){
           if(!(pixels1[r][c].getColor()).equals(pixels2[r][c].getColor())){
             return false;
           }
         }
        }
        return true;
       }
       else{
        return false;
       }
    }
    
    public static ArrayList<Point> findDifferences(Picture pic1,Picture pic2){
        Pixel[][] pixels1 = pic1.getPixels2D(); 
        Pixel[][] pixels2 = pic2.getPixels2D();
        ArrayList<Point> differences = new ArrayList<Point>();
        for(int row = 0;row < pixels1.length;row++){
            for(int col = 0; col<pixels1[row].length;col++){
                if(!(pixels1[row][col].getColor()).equals(pixels2[row][col].getColor())){
                differences.add(new Point(row,col));
              }
            }
        }
        
        return differences;
    }
    
    public static Picture showDifferentArea(Picture source, ArrayList<Point> points){
      Pixel[][] pixelSource = source.getPixels2D();
      for(Point p : points){
         pixelSource[(int)p.getX()][(int)p.getY()].setColor(Color.BLUE);
      }
      return source;
   }
   
   public static ArrayList<Integer> encodeString(String s) { 
       s = s.toUpperCase(); 
       String alpha = "ABCDEEFGHIJKLMNOPQRSTUVWXYZ"; 
       ArrayList<Integer> result = new ArrayList<Integer>(); 
       for (int i = 0; i < s.length(); i++){ 
           if (s.substring(i,i+1).equals(" ")){ 
               result.add(27); 
            } 
           else { 
               result.add(alpha.indexOf(s.substring(i,i+1))+1); 
            }    
        } 
       result.add(0); 
       return result; 
    } 
    
    public static String decodeString(ArrayList<Integer> codes){
    String result=""; 
    String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
    for (int i=0; i < codes.size(); i++){
        if (codes.get(i) == 27) { 
            result = result + " "; 
        } 
            else { result = result + alpha.substring(codes.get(i)-1,codes.get(i)); 
            }
        } 
   
    return result; 
  } 
  
  private static int[] getBitPairs(int num){
      int[] bits = new int[3];
      int code = num;
      for (int i = 0; i < 3; i++){
          bits[i] = code % 4;
          code= code / 4; 
        } 
      return bits;
  }
  public static void hideText(Picture source, String s){
    Pixel[][] pixels1 = source.getPixels2D();
    
    
    }
  
}

