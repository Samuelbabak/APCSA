
/**
 * Write a description of class game here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Game
{
    private Display display;
    
    public Game(int width, int height){
        display = new Display(width, height);
        
    }
    }
}
