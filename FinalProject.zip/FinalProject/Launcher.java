
/**
 * Write a description of class Launcher here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Launcher
{
    public static void main(String[] args){
        Screen screen = new Screen(1000,1000);
        new Thread(new GameLoop()).start();
    }
}
