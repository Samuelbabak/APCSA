
/**
 * Write a description of class Screen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JFrame;
import java.awt.*;
public class Screen extends JFrame
{
    private Canvas canvas;
    public Screen(int width, int height){
        setTitle("BloxShooter");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        
        canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(width, height));
        canvas.setFocusable(false);
        add(canvas);
        pack();
        
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
