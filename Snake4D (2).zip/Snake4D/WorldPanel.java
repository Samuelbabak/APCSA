
/**
 * Write a description of class DrawPanel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class WorldPanel extends JPanel implements KeyListener
{
    private static int boxSize = 40;
    
    private int xsize = 6;
    private int ysize = 5;
    private int zsize = 7;
    private int wsize = 6;
    
    public static double scale = 0.75;
    public static double scaledSize = boxSize*scale;
    public static double hexConst = boxSize*scale*(Math.sqrt(3)/2);
    
    private Snake snake;
    private Position pellet;
    private Position direction;
    
    private boolean dieNext = false;
    
    public WorldPanel(){
        newSnake();
        newPellet();
        addKeyListener(this);
    }
    
    private void newSnake(){
        //generates default snake
        ArrayList<Position> snakeTemp = new ArrayList<Position>();
        snakeTemp.add(new Position(1,1,1,1));
        snakeTemp.add(new Position(1,2,1,1));
        snake = new Snake(snakeTemp);
        direction = new Position(1,0,0,0);
    }
    
    private void newPellet(){
        //places pellet randomly, not on snake
        if(snake.size() >= xsize*ysize*zsize*wsize){return;}
        pellet = new Position((int)(Math.random()*xsize),
                              (int)(Math.random()*ysize),
                              (int)(Math.random()*zsize),
                              (int)(Math.random()*wsize));
        if(snake.isOnBody(pellet)){newPellet();}
    }
    
    public void nextState(){
        nextState(Position.sum(snake.headPos(),direction));
    }
    public void nextState(Position nextHead){
        //progresses game state
        if(isOOB(nextHead) || snake.isOnBody(nextHead)){
            //kills snake if this is called twice in a row
            if(dieNext){newSnake();}
            dieNext = true;
        }
        else if(Position.isEqual(nextHead,pellet)){
            //pellet collection
            snake.add(nextHead);
            newPellet();
            dieNext = false;
        }
        else{
            //snake motion
            snake.shift(nextHead); 
            dieNext = false;
        }
    }
    
    private boolean isOOB(Position nextHead){
        //returns true if next head position would be out of the world
        if(nextHead.getX() >= xsize || nextHead.getX() < 0
         ||nextHead.getY() >= ysize || nextHead.getY() < 0
         ||nextHead.getZ() >= zsize || nextHead.getZ() < 0
         ||nextHead.getW() >= wsize || nextHead.getW() < 0){
             return true;
        }
        return false;
    }
    
    public void keyPressed(KeyEvent e){
        //set next direction based on key pressed
        Position directionTemp = direction;
        if(e.getKeyCode() == e.VK_W){directionTemp = new Position(0,-1,0,0);}
        else if(e.getKeyCode() == e.VK_A){directionTemp = new Position(-1,0,0,0);}
        else if(e.getKeyCode() == e.VK_S){directionTemp = new Position(0,1,0,0);}
        else if(e.getKeyCode() == e.VK_D){directionTemp = new Position(1,0,0,0);}
        else if(e.getKeyCode() == e.VK_I){directionTemp = new Position(0,0,0,-1);}
        else if(e.getKeyCode() == e.VK_J){directionTemp = new Position(0,0,-1,0);}
        else if(e.getKeyCode() == e.VK_K){directionTemp = new Position(0,0,0,1);}
        else if(e.getKeyCode() == e.VK_L){directionTemp = new Position(0,0,1,0);}
        //only set if you're not trying to go backwards
        if(!Position.isEqual(Position.sum(snake.headPos(),directionTemp),snake.snakePosList().get(1))){
            direction = directionTemp;
        }
    }
    public void keyTyped(KeyEvent e){}
    public void keyReleased(KeyEvent e){}
    
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        
        //draw 2d world xy
        g.drawRect(0,0,boxSize*xsize,boxSize*ysize);
        //draw 2d world zw
        g.drawRect(boxSize*(xsize+1),0,boxSize*zsize,boxSize*wsize);
        
        //define base y pos of 3dX1d worl map
        int by = ysize;
        if(wsize > ysize){by=wsize;}
        by++;
        
        //draw 3d world xyz
        Cube worldMap3D = new Cube(0,boxSize*by,xsize,zsize,ysize);
        worldMap3D.drawFrame(g);
        //draw 1d world w
        g.drawRect((int)(hexConst*(xsize+zsize+1)),boxSize*by,(int)scaledSize,(int)(scaledSize*wsize));
        
        for(Position p : orderSnake(snake)){
            g.setColor(Color.BLACK);
           
            //draw 3d snake xyz
            if(snake.headPos().getW() == p.getW()){
                Cube piece = new Cube((int)(hexConst*(p.getX()+p.getZ())),(boxSize*by)+(int)((p.getX()+2*p.getY()-p.getZ()+by-1)*scaledSize/2),1,1,1);
                if(p == snake.snakePosList().get(0)){g.setColor(new Color(0,155,155));}
                piece.drawSolid(g);
            }
            //draw 1d snake w
            if(Position2D.isEqual(snake.headPos().getXY(),p.getXY())&&snake.headPos().getZ()==p.getZ()){
                g.fillRect((int)(hexConst*(xsize+zsize+1)),(int)(boxSize*(by+scale*p.getW())),(int)(scaledSize),(int)(scaledSize));
            }
            //draw 3d pellet xyz
            g.setColor(Color.BLACK);
            Cube pellet3d = new Cube((int)(hexConst*(pellet.getX()+pellet.getZ())),(boxSize*by)+(int)((pellet.getX()+2*pellet.getY()-pellet.getZ()+by-1)*scaledSize/2),1,1,1);
            pellet3d.drawFrame(g);
            //draw 1d pellet w
            g.drawRect((int)(hexConst*(xsize+zsize+1)),(int)(boxSize*(by+scale*pellet.getW())),(int)(scaledSize),(int)(scaledSize));
            
            //draw 2d snake xy
            if(Position2D.isEqual(snake.headPos().getZW(),p.getZW())){
                g.fillRect(boxSize*p.getX(),boxSize*p.getY(),boxSize,boxSize);
            }
            //draw 2d snake zw
            if(Position2D.isEqual(snake.headPos().getXY(),p.getXY())){
                g.fillRect(boxSize*(p.getZ()+xsize+1),boxSize*p.getW(),boxSize,boxSize);
            }
            //draw 2d pellet xy
            g.drawRect(boxSize*pellet.getX(),boxSize*pellet.getY(),boxSize,boxSize);
            //draw 2d pellet zw
            g.drawRect(boxSize*(pellet.getZ()+xsize+1),boxSize*pellet.getW(),boxSize,boxSize);   
        }
        g.setColor(new Color(0,155,155));
        //recolor 2d snake head xy
        g.fillRect(boxSize*snake.headPos().getX(),boxSize*snake.headPos().getY(),boxSize,boxSize);
        //recolor 2d snake head zw
        g.fillRect(boxSize*(snake.headPos().getZ()+xsize+1),boxSize*snake.headPos().getW(),boxSize,boxSize);
    }
    
    private static ArrayList<Position> orderSnake(Snake s){
        ArrayList<Position> ordered = new ArrayList<Position>();
        for(Position p : s.snakePosList()){
            boolean isLeast = true;
            for(int p2 = ordered.size()-1; p2 >= 0; p2--){
                if(p.get3DFrontways()>=ordered.get(p2).get3DFrontways()){
                    ordered.add(p2+1,p);
                    isLeast = false;
                    break;
                }
            }
            if(isLeast){ordered.add(0,p);}
        }
        return ordered;
    }
}
