
/**
 * Write a description of class Cube here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.*;
import javax.swing.*;
public class Cube
{
    private int baseX;
    private int baseY;
    private double xp;
    private double zp;
    private double xdif;
    private double ydif;
    private double zdif;
    
    public Cube(int x, int y, double l, double w, double h){
        baseX = x;
        baseY = y;
        xp = WorldPanel.hexConst*l;
        zp = WorldPanel.hexConst*w;
        xdif = l*WorldPanel.scaledSize/2;
        ydif = h*WorldPanel.scaledSize;
        zdif = w*WorldPanel.scaledSize/2;
    }
    
    public void drawFrame(Graphics g){
        //top face
        g.drawPolygon(new int[]{baseX+(int)zp,baseX,baseX+(int)xp,baseX+(int)(xp+zp)},
                      new int[]{baseY,baseY+(int)zdif,baseY+(int)(zdif+xdif),baseY+(int)xdif},
                      4);
        //bottom face
        g.drawPolygon(new int[]{baseX+(int)zp,baseX,baseX+(int)xp,baseX+(int)(xp+zp)},
                      new int[]{baseY+(int)ydif,baseY+(int)(ydif+zdif),baseY+(int)(ydif+zdif+xdif),baseY+(int)(ydif+xdif)},
                      4);
        //left face
        g.drawPolygon(new int[]{baseX+(int)zp,baseX+(int)zp,baseX,baseX},
                      new int[]{baseY,baseY+(int)ydif,baseY+(int)(ydif+zdif),baseY+(int)zdif},
                      4);
        //right face
        g.drawPolygon(new int[]{baseX+(int)(zp+xp),baseX+(int)(zp+xp),baseX+(int)xp,baseX+(int)xp},
                      new int[]{baseY+(int)xdif,baseY+(int)(xdif+ydif),baseY+(int)(xdif+ydif+zdif),baseY+(int)(xdif+zdif)},
                      4);
        //other faces implied by existing lines
    }
    /**
     * precondition: g.getColor()'s getRed(),getGreen(), and getBlue <= 155
     */
    public void drawSolid(Graphics g){
        //define colors
        Color col3 = g.getColor();
        Color col2 = new Color(col3.getRed()+50,col3.getGreen()+50,col3.getBlue()+50);
        Color col = new Color(col2.getRed()+50,col2.getGreen()+50,col2.getBlue()+50);
        //top face
        g.setColor(col);
        g.fillPolygon(new int[]{baseX,baseX+(int)(zp),baseX+(int)(xp+zp),baseX+(int)(xp)},
                      new int[]{baseY+(int)(xdif),baseY+(int)(xdif+zdif),baseY+(int)(zdif),baseY},
                      4);
        //front face
        g.setColor(col2);
        g.fillPolygon(new int[]{baseX,baseX,baseX+(int)zp,baseX+(int)zp},
                      new int[]{baseY+(int)xdif,baseY+(int)(xdif+ydif),baseY+(int)(xdif+ydif+zdif),baseY+(int)(xdif+zdif)},
                      4);
        //right face
        g.setColor(col3);
        g.fillPolygon(new int[]{baseX+(int)zp,baseX+(int)zp,baseX+(int)(xp+zp),baseX+(int)(xp+zp)},
                      new int[]{baseY+(int)(xdif+zdif),baseY+(int)(xdif+ydif+zdif),baseY+(int)(ydif+zdif),baseY+(int)(zdif)},
                      4);
    }
}
