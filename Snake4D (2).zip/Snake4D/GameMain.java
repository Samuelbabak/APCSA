
/**
 * Write a description of class GameMain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.image.*;
import javax.swing.border.*;
public class GameMain
{
    public int xTest = 30;
    
    private JFrame frame;
    private WorldPanel panel;
    
    public void repaint(){
        frame.repaint();
    }
    
    public static void main(String[] args){
        GameMain g = new GameMain();
    }
    
    public GameMain(){
        this.createWindow();
        this.run();
    }
    
    public void createWindow(){
        frame = new JFrame();
        panel = new WorldPanel();
        frame.add(panel);
        
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000,1000);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
    public static int cycles = 0;
    public void run(){
        long time = System.currentTimeMillis();
        int numCycles = 17;
        while(true){
            if(System.currentTimeMillis() >= (time+17)){
                panel.requestFocus();
                time = System.currentTimeMillis();
                if(cycles < numCycles){cycles++;}
                else{
                    panel.nextState();
                    panel.repaint();
                    cycles = 0;
                }
            }
        }
    }
}
