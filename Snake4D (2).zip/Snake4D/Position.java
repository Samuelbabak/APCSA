
/**
 * Enumeration class Direction - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Position
{
    private Position2D xy;
    private Position2D zw;
    
    public Position(int xp, int yp, int zp, int wp){
        xy = new Position2D(xp,yp);
        zw = new Position2D(zp,wp);
    }
    public Position(Position2D xyp, Position2D zwp){
        xy = xyp;
        zw = zwp;
    }
    
    public static Position sum(Position a, Position b){
        return new Position(Position2D.sum(a.xy,b.xy),
                            Position2D.sum(a.zw,b.zw));
    }
    public static boolean isEqual(Position a, Position b){
        return (Position2D.isEqual(a.xy,b.xy)
              &&Position2D.isEqual(a.zw,b.zw));
    }
    
    public Position2D getXY(){return xy;}
    public Position2D getZW(){return zw;}
    public int getX(){return xy.getX();}
    public int getY(){return xy.getY();}
    public int getZ(){return zw.getX();}
    public int getW(){return zw.getY();}
    public int get3DFrontways(){return xy.getX()-xy.getY()-zw.getX();}
}
