
/**
 * Write a description of class Snake here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Snake
{
    private ArrayList<Position> segmentsPos;
    
    public Snake(ArrayList<Position> posList){
        segmentsPos = posList;
    }
    
    public int size(){return segmentsPos.size();}
    public ArrayList<Position> snakePosList(){return segmentsPos;}
    public Position headPos(){return segmentsPos.get(0);}
    public Position tailPos(){return segmentsPos.get(segmentsPos.size()-1);}
    
    public void shift(Position headPos){
        //add position to front of list, remove position from back of list
        segmentsPos.add(0, headPos);
        segmentsPos.remove(segmentsPos.size()-1);
    }
    
    public boolean isOnBody(Position p){
        for(Position sp : segmentsPos){
            if(Position.isEqual(sp,p)){return true;}
        }
        return false;
    }
    
    public boolean isOnHead(Position p){
        return Position.isEqual(segmentsPos.get(0),p);
    }
    
    public void add(Position headPos){
        segmentsPos.add(0, headPos);
    }
}
