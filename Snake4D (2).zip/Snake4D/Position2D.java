
/**
 * Write a description of class Position2D here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Position2D
{
    private int x;
    private int y;
    
    public Position2D(int xp, int yp){
        x = xp;
        y = yp;
    }
    
    public static boolean isEqual(Position2D a, Position2D b){
        return (a.x == b.x && a.y == b.y);
    }
    public static Position2D sum(Position2D a, Position2D b){
        return new Position2D(a.x + b.x, a.y + b.y);
    }
    
    public int getX(){return x;}
    public int getY(){return y;}
}
