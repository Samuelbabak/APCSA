
/**
 * Write a description of class WinterMountain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class WinterMountain extends Mountain
{
    private int temperature;
    public WinterMountain(int length, int width, int moun, int temp){
        super(length,width,moun);
        temperature = temp;
    
    }
    public double getTemp(){
        return temperature;
    }
}
