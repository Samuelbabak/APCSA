
/**
 * Write a description of class Forest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Forest extends Terrain
{   
    private int trees;
    public Forest(int l, int w, int tree){
    super(l,w);
    trees = tree;
    }
    public int getTrees(){
    return trees;
    }
}
