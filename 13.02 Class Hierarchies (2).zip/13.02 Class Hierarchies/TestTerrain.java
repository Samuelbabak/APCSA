
/**
 * Write a description of class TestTerrain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestTerrain
{
    public static void main(String []args){
        Terrain land = new Terrain(100,500);
        Mountain m = new Mountain(100,500,25);
        Forest f = new Forest(100,500,11);
        WinterMountain w = new WinterMountain(100,522,25,10);
        System.out.println("Forest " + f.getTerrain() + " and has " + f.getTrees() +" trees.");
        System.out.println("Mountain " + m.getTerrain() + " and has " + m.getMountains() +" mountains.");
        System.out.println("Winter Mountain " + w.getTerrain() +" and has a temperature of " + w.getTemp() + " degrees and " + m.getMountains() +" mountains.");
    }
}
