
/**
 * Write a description of class Mountain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Mountain extends Terrain
{
    private int mountains;
    public Mountain(int length, int width, int m) {
        super(length,width);
        mountains = m;
   }
   public int getMountains(){
       return mountains;
    }
}
