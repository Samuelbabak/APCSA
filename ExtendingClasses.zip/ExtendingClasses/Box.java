
/**
 * Write a description of class Box here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Box
{   
    private static int length;
    private static int width;
    public Box(int length,int width){
        this.length=length;
        this.width=width;
    }
    public static String boxToString(){
    return "box's dimensions are " + length + " x " + length;
    }
}
