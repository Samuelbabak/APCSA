
/**
 * Write a description of class a here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class a
{
public int centeredAverage(int[] nums) {
  int max=Integer.MAX_VALUE;
  int min=Integer.MIN_VALUE;
  int total=0;
  for(int i =0;i<nums.length;i++){
    max=Math.max(max,nums[i]);
    min=Math.min(min,nums[i]);
  }
  for(int i =0;i<nums.length;i++){
    if(i==nums.findIndex(min) || (i==nums.findIndex(max))){   
      
    }
    else{
      total+=nums[i];
    }
  }
  return total/(nums.length-2);
}

    }
