
/**
 * Write a description of class cube here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class cube extends Box
{
    private static int height;
    public cube(int len){
        super(int length, int width,int height);
    }
}
