
/**
 * This program will show the user ther estimated salary
 *
 * Samuel Babak
 */
import java.util.Scanner;

public class testaa
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter Your Name:  ");
        String name = new String( in.next() );
        System.out.println("Hello " + name);
        System.out.println("Enter your age: ");
        int age = in.nextInt();
         while (age > 100 || age<10)
           {
               if (age<10)
               {
                System.out.println("You cannot be younger than 10!");
                System.out.println("Please enter name: ");
                age = in.nextInt();
            }
               else
               {
                System.out.println("Please enter your real age!: ");
                age = in.nextInt();
            }}
        System.out.println("your age is: " + age);
        System.out.println("what is your level of awesomeness(1-10): ");
        int awes = in.nextInt();
            while (awes > 10|| awes<1)
           {
                System.out.println("what is your level of awesomeness(1-10): ");
                awes = in.nextInt();
            }
        double salary = Math.pow(Math.pow(age,2)/awes,2)*52;
        System.out.println("your salary is: " + salary + " a year");
        in.close();
    }
        
        
        
    }

