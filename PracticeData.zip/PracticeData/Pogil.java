
/**
 * Write a description of class Pogil here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Pogil
{
    public static void main(String[] args)
    {
        int a = 3, b = 4, c = 5;
        boolean p = a<b;
        boolean q = !(b > c);
        System.out.println("p && q");
        System.out.println(! (a>c);
        String hey = new String("help");

    }
}
