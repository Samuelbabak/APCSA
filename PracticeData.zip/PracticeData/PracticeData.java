
/**
 * this program is meant to play around with java data types.
 * samuel babal
 */
public class PracticeData
{
    public static void main(String[] args)
    {
     int a;
     double b;
     boolean c;
     String name = new String("Samuel");
     
     System.out.print(name + "\n");
     System.out.print(name + "\t");
     System.out.println("\"" + name + "\"");
     System.out.println("\\" + name + "\\");
     
     int side1 = 3;
     int side2 = 4;
     double hyp = Math.sqrt(side1*side1 + side2*side2);
     System.out.println(hyp);
     
     
     int a1 = 5;
     double b2 = 6;
     double b3 = 4.3;
     
     double z = b2 + b3;
     System.out.println(z);
     z+= 2;
     System.out.println("after adding 2:  " + z);
     
     a1 -= 2;
     System.out.println("5 minus 2 is:    " + a1);
     int a2 = 3;
     a2 *= 4;
     System.out.println("3 times 4 is   " + a2);
     int a3  = 12;
     a3 /= 3;
     System.out.println("12 divided by 3 is "   + a3);
     
     int a4 = 5;
     a4 %= 3;
     System.out.println("5 mod 3 is :" + a4);
     
     
     int i = 0;
     int j = 10;
     i++;
     j--;
     System.out.println("i++ gives us " + i);
     System.out.println("j-- gives us " + j);
     
     final int var_Name = 3;
     var_Name = 10;
     
    }
}
