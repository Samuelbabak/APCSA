
/**
 * This gives the user a survey
 *
 * Samuel Babak
 */
import java.util.Scanner;
import java.util.Random;
public class MySecondApp

{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("-----------welcome-----------");
        System.out.println("Please enter the answers below");
        System.out.println("------------------------------");
        System.out.println("your favorite integer is: " );
        int fi = in.nextInt();
        System.out.println("------------------------------");
        System.out.println("your favorite double is: ");
        double fd = in.nextDouble();
        System.out.println("------------------------------");
        System.out.println("you are in school (true/false)= ");
        Boolean test = in.nextBoolean();
        System.out.println("------------------------------");
        System.out.println("who is your favorite person = " );
        String help = new String( in.next() );
        System.out.println("------------------------------");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        System.out.println("--------Calculating--------");
        try 
        {
            Thread.sleep(2000);
        } 
        catch(InterruptedException e)
        {
            }
        Random rand = new Random();
        int n = rand.nextInt(2);
            if (n==1)
            {
                System.out.println("yore gae" );
            }
            else
            {
                System.out.println(fi + " is your favorite integer" );
                System.out.println(fd + " is your favorite double");
                    if (test=true)
                    {    
                        System.out.println("you are in school");
                    }
                    else
                    {
                        System.out.println("you are not in school");
                    }
                System.out.println(help + " is your favorite person");
    }
  }
}