import java.util.Scanner;
public class quads
{
    public static void hold(int waitTime)
        {
         try
        {
            Thread.sleep(waitTime);
        }
        catch(InterruptedException e)
        {
        }   
        }
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.println("\n\n\n");
        System.out.println("-----------------------------");
        System.out.println(" Quadratic Formula Calculator");
        System.out.println("-----------------------------");
        System.out.println("\n");
        System.out.println("input an \"A\" value--");
        int a = in.nextInt();
        System.out.println("input a \"B\" value--");
        int b = in.nextInt();
        System.out.println("\n");
        hold(1500);
        System.out.println("The value of b^2 is = " + Math.pow(b,2));
        hold(1500);
        System.out.println("\n");
        System.out.println("input a \"C\" value--");
        int c = in.nextInt();
        double bs = Math.pow(b,2);
        double dee = (bs-4*a*c);
        double desc = Math.sqrt(bs-4*a*c);
        while (dee<0)
        {
         System.out.println("Sorry, your discriminant is negitive. We cannot process an imaginary root right now");
         System.out.println("Please enter a new \"A\" value");
         a = in.nextInt();
         System.out.println("input a \"B\" value--");
         b = in.nextInt();
         System.out.println("input a \"C\" value--");
         c = in.nextInt();
        }
        System.out.println("The value of your discriminant = " + desc);
        double FinalPos = (desc+b)/(2*a);
        double FinalNeg = (desc-b)/(2*a);
        System.out.println("your answers are " + FinalPos + " and " + FinalNeg);
    }
}
