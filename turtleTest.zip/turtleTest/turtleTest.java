
/**
 * Write a description of class Turtle here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class turtleTest
{
    public static void main(String[] args)
    {
        int distance;                 // line 1
        World window;
        Turtle turtle1;
        window = new World();         // line 4
        turtle1 = new Turtle(window);
        turtle1.forward(100);         // line 6
        turtle1.turnLeft();
    }
}
