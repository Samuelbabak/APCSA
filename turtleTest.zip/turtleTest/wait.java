
/**
 * Write a description of class wait here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class wait
{
    waits(); {
    try
        {
            Thread.sleep(1500);
        }
        catch(InterruptedException e)
        {
        }
    }
}