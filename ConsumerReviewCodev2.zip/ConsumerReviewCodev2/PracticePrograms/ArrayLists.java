
/**
 * Write a description of class ArrayLists here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ArrayLists
{   
    private static String[] cars = {"Honda","civic","acura" };
    public static String randomcCar() {
        int randomNumber = (int)(Math.random()*5);
        return cars[randomNumber];
    }
}
