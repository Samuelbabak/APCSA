
import java.util.ArrayList;
import java.util.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
public class SimpleRandomSentences {
    private static final String[] conjunctions = {"and", "or", "but", "because"};

    private static final String[] proper_nouns = {"Sam", "Liam", "Zack", "Aiden", "Hunter","Clay","Savannah", "Brook","Richard","Thomas","Nathan Cree","Nathan Loomis","Coltrane","Toby","Tyler","Reid","Marshall"};
    
    private static ArrayList<String> common_nouns = new ArrayList<String>();

    private static final String[] determiners = {"a", "the", "every", "some"};

    private static ArrayList<String> adjectives = new ArrayList<String>();
    
    private static ArrayList<String> intransitive_verbs = new ArrayList<String>();
    
    private static ArrayList<String> transitive_verbs = new ArrayList<String>();
    
    private static String sentence = "";

    /**
     * The main routine prints out one random sentence every three
     * seconds, forever (or until the program is killed).
     */
    public static void main(String[] args) throws IOException {
        PrintWriter outFile = new PrintWriter(new File("Spam.txt"));
        try{
            Scanner in = new Scanner(new File("common_nouns.csv"));    
            String token = "";
            while(in.hasNextLine())
            {
                token = in.nextLine().trim();
                if(!token.equals(""))
                {
                    common_nouns.add(token);
                }
            }
            in.close();
            in = new Scanner(new File("adjectives.csv"));
            while(in.hasNextLine())
            {
                token = in.nextLine().trim();
                if(!token.equals(""))
                {
                    adjectives.add(token);
                }
            }
            in.close();
            in = new Scanner(new File("intransitive_verbs.csv"));
            while(in.hasNextLine())
            {
                token = in.nextLine().trim();
                if(!token.equals(""))
                {
                    intransitive_verbs.add(token);
                }
            }
            in.close();
            in = new Scanner(new File("transitive_verbs.csv"));
            while(in.hasNextLine())
            {
                token = in.nextLine().trim();
                if(!token.equals(""))
                {
                    transitive_verbs.add(token);
                }
            }
            in.close();
        }catch(Exception e)
        {
            System.out.println("error reading in files");
        }
        for(int t=0;t<10;t++){
            randomSentence();
            System.out.print(sentence + t);
            System.out.println(".\n\n");
            outFile.println(sentence.trim() + ".\n");
        }
        outFile.close();
    }

    /**
     * Generate a random sentence, following the grammar rule for a sentence.
     */
    static void randomSentence() {
        sentence = "";
        /* A simple sentence */

        randomSimpleSentence();
        if(sentence.contains(" a ") && (sentence.charAt(sentence.indexOf(" a ") + 3) == 'a' ||
        sentence.charAt(sentence.indexOf(" a ") + 3) == 'e' ||
        sentence.charAt(sentence.indexOf(" a ") + 3) == 'i' ||
        sentence.charAt(sentence.indexOf(" a ") + 3) == 'o' ||
        sentence.charAt(sentence.indexOf(" a ") + 3) == 'u'))
        {
            sentence = sentence.substring(0,sentence.indexOf(" a ")+2) + "n" + sentence.substring(sentence.indexOf(" a ")+2);
        }
        if(sentence.substring(0,1).equals("a") && (sentence.charAt(2) == 'a' ||
        sentence.charAt(sentence.indexOf(2) + 3) == 'e' ||
        sentence.charAt(sentence.indexOf(2) + 3) == 'i' ||
        sentence.charAt(sentence.indexOf(2) + 3) == 'o' ||
        sentence.charAt(sentence.indexOf(2) + 3) == 'u'))
        {
            sentence = sentence.substring(0,1) + "n" + sentence.substring(1);
        }
        sentence = sentence.trim();
        
        /* Optionally, "and" followed by another simple sentence.*/
        
        if (Math.random() > 0.75) { // 25% of sentences continue with another clause.
            sentence += " " + conjunctions[(int)(conjunctions.length*Math.random())] + " ";
            randomSimpleSentence();
            sentence = sentence.trim();
        }
        sentence = sentence.substring(0,1).toUpperCase() +  sentence.substring(1);
    }

    /**
     * Generate a random simple_sentence, following the grammar rule for a simple_sentence.
     */
    static void randomSimpleSentence() {
        randomNounPhrase();
        randomVerbPhrase();
    }

    /**
     * Generates a random noun_phrase, following the grammar rule for a noun_phrase.
     */
    static void randomNounPhrase() {
        if(Math.random() < 0.5)
        {   
            int n = (int)(proper_nouns.length*Math.random());
            sentence += proper_nouns[n] + " ";
        }
        else
        {
             //<determiner> [ <adjective> ]... <common_noun> [ who <verb_phrase> ]
             int n = (int)(determiners.length*Math.random());
             sentence += determiners[n] + " ";
             
             while(Math.random() < 0.25)
             {
                 n = (int)(adjectives.size()*Math.random());
                 sentence += adjectives.get(n) + " ";
             }
             
             n = (int)(common_nouns.size()*Math.random());
             sentence += common_nouns.get(n) + " ";
             
             if(Math.random() < 0.25)
             {
                 sentence += "who ";
                 randomVerbPhrase();
             }
        }
    }
    
    static void randomVerbPhrase()
    {
         //<verb_phrase> ::= <intransitive_verb> | 
         //             <transitive_verb> <noun_phrase> |
         //             is <adjective> |
         //             believes that <simple_sentence>
         double randNum = Math.random();
         if(randNum < 0.25)
         {
             int n = (int)(intransitive_verbs.size()*Math.random());
             sentence += intransitive_verbs.get(n).trim() + " ";
         }
         else if(randNum < 0.5)
         {
             int n = (int)(transitive_verbs.size()*Math.random());
             sentence += transitive_verbs.get(n).trim() + " ";
             randomNounPhrase();
         }
         else if(randNum < 0.75)
         {
             int n = (int)(adjectives.size()*Math.random());
             sentence += "is " + adjectives.get(n).trim() + " ";
         }
         else
         {
             sentence += "believes that ";
             randomSimpleSentence();
         }
    }
}