
/**
 * Write a description of class toBinary here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class toBinary
{
    public static String toBinary(String str)

  {
    if (str.length() < 1){
        return "";
    }
    else{
        return str.substring(0, 1) + toBinary(str.substring(1));
     }
  }
  public static void main(String[] args) {
    toBinary("how");
   }
}

