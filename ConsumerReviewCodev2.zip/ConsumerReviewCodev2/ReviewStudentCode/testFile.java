public class testFile{
    public static void main(String[] args){
    String word="how! ARE you!@#$%^&*";
    word = word.toLowerCase();
    System.out.println(word.replaceAll("\\p{Punct}+", ""));
    }
}