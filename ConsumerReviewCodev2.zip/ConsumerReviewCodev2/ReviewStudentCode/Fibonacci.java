
/**
 * Write a description of class Fibonacci here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Fibonacci
{
  public static int squence(int n){
    if(n==0){
    return 0;
    }
    else if(n==1){
    return 1;
    }
    else{
    return (squence(n-1)+squence(n-2));
    }
   }
  public static void main(String[] args){
      Scanner in = new Scanner(System.in);
      String input = in.nextLine();
      int number;
      while(!input.equals("q")){
        number = Integer.parseInt(input);
        System.out.println(squence(number));
        input = in.nextLine();
        }
  }
}
