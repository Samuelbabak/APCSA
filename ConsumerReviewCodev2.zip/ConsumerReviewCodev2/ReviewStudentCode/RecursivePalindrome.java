/**
 * Write a description of class RecursivePalindrome here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RecursivePalindrome
{
   private static String newWord="";
   public static boolean Palindrome(String word){
      boolean isPalindrome=false;
      Helper(word);
      
      if(newWord.length()==0){
        isPalindrome=true;
        }
      else if(newWord.charAt(0)==newWord.charAt(newWord.length()-1)){
         if(newWord.length()>1) {
             isPalindrome = Palindrome(newWord.substring(1,newWord.length()-1));
         }  
         else{
             isPalindrome=true;
         }
       }
      return isPalindrome;
   }
   
   public static String Helper(String word){
     word = word.toLowerCase();
     newWord="";
      for(int i = 0; i<word.length();i++){
        if((int)(word.charAt(i))>96 && (int)(word.charAt(i))<123)
        {
         newWord += word.charAt(i);
        }
      }
     word=newWord;
     return newWord;
    }
}