/**
 * Write a description of class CerealTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
public class VideoGanesTester
{
    //This will hold our list of Cereal objects
    private static ArrayList<VideoGames> VideoGamesList = new ArrayList<VideoGames>();
    
    
    public static double findMinRating(ArrayList<VideoGames> VideoGamesList){
      int index = 0;
      double maxVal = Integer.MIN_VALUE;
      
      for (VideoGames game : VideoGamesList){
        if(game.getRating() > maxVal) {
          maxVal = game.getRating();
          index = VideoGamesList.indexOf(game);
        }
      }
      
      System.out.println("the game with the lowest rating is: "+ VideoGamesList.get(index).getName() +" with a " + VideoGamesList.get(index).getRating() + " star rating");
       return maxVal;
     }   
    
    
    
    public static void main(String[] args)
    {
        try {
            Scanner input = new Scanner(new File("vgsales-12-4-2019.csv"));
            input.nextLine(); //First line of file is just a header
            while(input.hasNextLine()){
                String[] temp = input.nextLine().split(",");    //comma-separated values
                for(int i =0;i<temp.length;i++) {
                   if (temp[i].equals("")){
                       temp[i]="0";
                    }
                }
                 /*
                 * This next line is VERY specific to cereal.csv and the order of
                 * the columns in that document. Additionally, the order matters
                 * to our Cereal constructor, since it expects certain parameters
                 * in a certain order.
                 */
                VideoGamesList.add(new VideoGames(Integer.parseInt(temp[0]),temp[1],temp[2],temp[3],temp[4],temp[5],temp[6],temp[7],temp[8],Double.parseDouble(temp[9]),Double.parseDouble(temp[10]),
                Double.parseDouble(temp[11]),Double.parseDouble(temp[12]),Double.parseDouble(temp[13]),Double.parseDouble(temp[14]),Double.parseDouble(temp[15]),Double.parseDouble(temp[16]),
                Integer.parseInt(temp[17]), temp[18],temp[19],Integer.parseInt(temp[20]),Double.parseDouble(temp[21]),temp[22]));
            }
            input.close();
        }
        catch(Exception e){
            /*
             * If there is an issue finding, reading, or parsing the file
             * to create Cereal objects, display this message.
             */
            System.out.println("Error: "+e);
        }
        
        //one example of why it's useful to have Cereal objects!
        findMinRating(VideoGamesList);
    }
}
