
/**
 * Write a description of class RecursivePalindromeTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class RecursivePalindromeTester 
{
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      System.out.println("Please enter a word.");
      String userComment=input.next();
       while(!userComment.equals("q")){
        if(RecursivePalindrome.Palindrome(userComment)){
            System.out.println(userComment + " is a palindrome.");
        }
        else {
            System.out.println(userComment + " is not a palindrome.");
        }
        
        System.out.println("\n\n\nPlease enter a word.");
        userComment=input.next();
      }
    }
}
