
/**
 * Write a description of class VideoGames here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VideoGames
{   
    private int rank;
    private String name;
    private String baseName;
    private String genre;
    private String rating;
    private String platform;
    private String publisher;
    private String developer;
    private String vgchartz;
    private double criticScore;
    private double userScore;
    private double total;
    private double globalSales;
    private double naSales;
    private double palSales;
    private double jpSales;
    private double otherSales;
    private int year;
    private String lastUpdate;
    private String url;
    private int status;
    private double vgchartzScore;
    private String imgUrl;
    public VideoGames(int rank,String name,String baseName, String genre, String rating, 
    String platform,String publisher, String developer, String vgchartz, double criticScore, 
    double userScore, double total, double globalSales, double naSales, 
    double palSales, double jpSales, double otherSales, int year, 
    String lastUpdate, String url, int status, double vgchartzScore, String imgUrl) {
        this.rank=rank;
        this.name=name;
        this.baseName=baseName;
        this.genre=genre;
        this.rating=rating;
        this.platform=platform;
        this.publisher=publisher;
        this.developer=developer;
        this.vgchartz=vgchartz;
        this.criticScore=criticScore;
        this.userScore=userScore;
        this.total=total;
        this.globalSales=globalSales;
        this.naSales=naSales;
        this.palSales=palSales;
        this.jpSales=jpSales;
        this.otherSales=otherSales;
        this.year=year;
        this.lastUpdate=lastUpdate;
        this.url=url;
        this.status=status;
        this.vgchartzScore=vgchartzScore;
        this.imgUrl=imgUrl;
    }
    public String getName(){
    return name;
    }
    public String getPlatform(){
    return platform;
    }
    public double getRating() {
    return userScore;
    }
    public String toString() {
    return (year+" \t"+name+" \tRank:"+rank+" \tPlatform:"+platform+" \tRating:"+rating);
    }
}
