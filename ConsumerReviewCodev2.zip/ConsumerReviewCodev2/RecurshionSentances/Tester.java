
/**
 * Write a description of class Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tester
{
    public static void main(String[] args){
    while(true){
        System.out.println((int)(Math.random()*4));
  }   
 }
}
