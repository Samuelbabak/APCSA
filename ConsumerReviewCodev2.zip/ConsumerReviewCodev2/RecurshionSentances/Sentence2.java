/**
 * Write a description of class SillySentences here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
public class Sentence2
{
  static private final String[] conjunction = {"and","or","but","because","so","after","as long as","that"};
  static private final String[] properNoun = {"Elijah","Makenna","Judd","Jose","Samuel","Christian","David","Colby","Hunter","Graham"};
  static private ArrayList<String> commonNoun = new ArrayList<String>();
  static private final String[] determiner = {"a","the","every","some"};
  static private final String[] adjective = {"big","tiny","pretty","bald"};
  static private final String[] intransitiveVerb = {"runs","jumps","talks","sleeps"};
  static private final String[] transitiveVerb = {"loves","hates","sees","knows","looks for","sleeps","pokes","stabs","rubs","strokes"};
  static private String phrase = "";
    public static void main(String[] args) throws IOException{
     Scanner in = new Scanner(new File("common_nouns.csv"));
     
     while(in.hasNextLine()){
     commonNoun.add(in);
        }
     PrintWriter outFile = new PrintWriter(new File("Thoughts.txt"));   
        for(int t=0;t<1000000;t++){
        sentence();
        phrase = phrase.substring(0,1).toUpperCase() + phrase.substring(1);
        System.out.print(phrase.trim() + ".\n");
        
        outFile.println(phrase.trim() + ".\n");
        phrase = "";
        
     } 
     outFile.close();
  } 
  static void simpleSentence(){
    nounPhrase();
    verbPhrase();
    }
  static void sentence(){
    simpleSentence();
     if(Math.random()>0.5){
     phrase += (conjunction[(int)(Math.random()*conjunction.length)] + " ");
     sentence();
    }
   }
  static void nounPhrase(){
    
    if(Math.random()<.5){
        phrase +=(properNoun[(int)(Math.random()*properNoun.length)] + " ");
    }
    else{
        phrase +=(determiner[(int)(Math.random()*determiner.length)]+ " ");
        if(Math.random()<.75){
            phrase +=(adjective[(int)(Math.random()*adjective.length)] + " ");
            if(Math.random()<.75){
            phrase +=(adjective[(int)(Math.random()*adjective.length)] + " ");
            if(Math.random()<.75){
            phrase +=(adjective[(int)(Math.random()*adjective.length)] + " ");
           }
          }
        }
        phrase +=(commonNoun[(int)(Math.random()*6)] + " ");
        if(Math.random()<0.26){
            phrase +=("who ");
            verbPhrase();
        }
    }
    
    }
  static void verbPhrase(){
     if(Math.random()<.25){
       phrase +=(intransitiveVerb[(int)(Math.random()*4)] + " ");  
        }
     else if(Math.random()>.25 && Math.random()<.5){
       phrase +=(transitiveVerb[(int)(Math.random()*10)] + " ");
       nounPhrase();
        }
     else if(Math.random()>.5 && Math.random()<.75){
       phrase +=("is " + adjective[(int)(Math.random()*4)] + " ");
        }
     else{
       phrase +=("believes that ");   
       simpleSentence();
        }
  }
}
